<?php defined('BASEPATH') or die('Something went wrong, please contact admin');
class faq_model extends CI_Model
{

}
?>